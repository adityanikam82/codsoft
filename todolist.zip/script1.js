document.addEventListener('DOMContentLoaded', function () {
    loadTasks();
});

function addTask() {
    const newTaskInput = document.getElementById('new-task');
    const taskText = newTaskInput.value.trim();

    if (taskText !== '') {
        const taskList = document.getElementById('task-list');

        const taskItem = document.createElement('li');
        taskItem.innerHTML = `
            <span>${taskText}</span>
            <button onclick="deleteTask(this)">Delete</button>
        `;

        taskList.appendChild(taskItem);

        saveTask(taskText);

        newTaskInput.value = '';
    }
}

function deleteTask(button) {
    const taskList = document.getElementById('task-list');
    const taskItem = button.parentNode;
    const taskText = taskItem.querySelector('span').innerText;

    taskList.removeChild(taskItem);

    removeTask(taskText);
}

function saveTask(taskText) {
    let tasks = getTasks();
    tasks.push(taskText);
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function removeTask(taskText) {
    let tasks = getTasks();
    tasks = tasks.filter(task => task !== taskText);
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function loadTasks() {
    const tasks = getTasks();
    const taskList = document.getElementById('task-list');

    tasks.forEach(taskText => {
        const taskItem = document.createElement('li');
        taskItem.innerHTML = `
            <span>${taskText}</span>
            <button onclick="deleteTask(this)">Delete</button>
        `;

        taskList.appendChild(taskItem);
    });
}

function getTasks() {
    const tasksString = localStorage.getItem('tasks');
    return tasksString ? JSON.parse(tasksString) : [];
}
